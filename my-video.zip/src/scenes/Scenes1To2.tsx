import React from "react";
import { useCurrentFrame, useVideoConfig, interpolate } from "remotion";
import { Theme } from "../theme";
import { Layout } from "../layout";
import {
  RafiPerson,
  CementSack,
  PulleyWheel,
  TwoStoryHouse,
  WaterTank,
  PhysicsBookCard,
  PopIn,
  Idle
} from "../art/Kit";
import {
  MetricChip,
  StampBanner,
  ForceArrow,
  RingPulse
} from "../components/Annotations";
import { clamp01 } from "../motion";
import { FONT_BENGALI } from "../fonts";

// ══════════════════════════════════════════════════════════════════════════
// দৃশ্য ১ (০:০০ - ০:৪০.৫): ৫০ কেজির বস্তা একা তোলার ব্যর্থ চেষ্টা ও পদার্থবিজ্ঞান তত্ত্ব
// ══════════════════════════════════════════════════════════════════════════
export const Scene1Struggle: React.FC<{ theme: Theme; layout: Layout }> = ({ theme }) => {
  const f = useCurrentFrame();
  const { fps } = useVideoConfig();
  const t = f / fps;

  // ০–১৩.৬s: রাফি মোটা পাটের দড়ি ধরে টানছে, বস্তা এক ইঞ্চিও নড়ছে না
  // ১৩.৬–২২.২s: দড়ি ছেড়ে হাঁটুতে হাত রেখে হাঁপাচ্ছে, ছাদে পানির ট্যাংক দেখা যাচ্ছে
  // ২২.২–৪০.৫s: সামনে এসএসসি পরীক্ষা, পদার্থবিজ্ঞান বইয়ের সূত্র ও ভারী বস্তার নিচে তত্ত্ব চাপা পড়া
  const isPulling = t < 13.6;
  const isPanting = t >= 13.6 && t < 22.5;
  const showBook = t >= 22.2;
  const bookCrushed = t >= 35.5;

  const groundY = 1180;
  const roofY = 460;
  const rafiX = 720;
  const sackX = 500;

  // বইটা ভারী বস্তার নিচে চাপা পড়ার অ্যানিমেশন (৩৫.৭s-এ)
  const bookY = bookCrushed
    ? interpolate(t, [35.5, 36.4], [740, 1110], { extrapolateLeft: "clamp", extrapolateRight: "clamp" })
    : 740;
  const bookScaleY = bookCrushed
    ? interpolate(t, [36.0, 36.7], [1, 0.45], { extrapolateLeft: "clamp", extrapolateRight: "clamp" })
    : 1;

  return (
    <g>
      {/* পেছনের ও মাঝের স্তর: দোতলা বাড়ি ও ছাদে নতুন পানির ট্যাংক */}
      <TwoStoryHouse theme={theme} groundY={groundY} floor1Y={820} roofY={roofY} buildingX={100} buildingW={330} dim={showBook && !bookCrushed} />

      <PopIn at={Math.round(16.5 * fps)} x={265} y={roofY - 22}>
        <Idle amp={2} speed={2}>
          <WaterTank theme={theme} scale={1.05} lit={t >= 17 && t < 22.5} />
        </Idle>
      </PopIn>

      {/* ভূমি-রেখা */}
      <line x1={60} y1={groundY} x2={1020} y2={groundY} stroke={theme.text} strokeWidth={5} strokeLinecap="round" />

      {/* মোটা পাটের দড়ি (সরাসরি বস্তা থেকে রাফির হাতে) */}
      {isPulling && (
        <g>
          <path
            d={`M ${sackX} ${groundY - 125} Q 610 ${groundY - 210} ${rafiX - 25} ${groundY - 195}`}
            fill="none"
            stroke={theme.warn}
            strokeWidth={8}
            strokeDasharray="14 6"
            strokeDashoffset={-f * 1.2}
          />
          <RingPulse x={rafiX - 25} y={groundY - 195} color={theme.bad} r={26} />
        </g>
      )}

      {/* পদার্থবিজ্ঞান বই ও সূত্রের কার্ড (২২.২ সেকেন্ডে আসে) */}
      {showBook && (
        <g transform={`translate(540 ${bookY}) scale(1 ${bookScaleY})`}>
          <Idle amp={4} speed={2.5}>
            <PhysicsBookCard theme={theme} scale={1.08} />
          </Idle>
        </g>
      )}

      {/* সামনের স্তর: ৫০ কেজির সিমেন্টের বস্তা (এক ইঞ্চিও নড়ে না) */}
      <g transform={`translate(${sackX} ${groundY})`}>
        <CementSack theme={theme} scale={1.18} bad={t >= 8.4 && t < 14} warn={bookCrushed} label="৫০ কেজি" />
      </g>

      {/* সামনের স্তর: রাফি (চশমা, ঘাম, লালচে হাতের তালু) */}
      <g transform={`translate(${rafiX} ${groundY})`}>
        <Idle amp={isPanting ? 5 : 2.5} speed={isPanting ? 6 : 2.5}>
          <RafiPerson
            pose={isPulling ? "pull" : isPanting ? "pant" : "study"}
            theme={theme}
            scale={1.38}
            sweat={true}
            redPalm={t >= 2.2 && t < 13.6}
            shake={isPulling ? 3.5 : 0}
          />
        </Idle>
      </g>

      {/* টীকা-স্তর (চিপ ও স্ট্যাম্প - প্রতি বিটে ≤ ৪) */}
      <MetricChip
        x={500}
        y={940}
        at={Math.round(8.5 * fps)}
        value="৫০ কেজি"
        unit="সিমেন্টের বস্তা"
        status="bad"
        theme={theme}
      />

      {t >= 11.0 && t < 22.0 && (
        <StampBanner
          x={540}
          y={600}
          at={Math.round(11.0 * fps)}
          text="✕ ১ ইঞ্চিও নড়ল না!"
          status="bad"
          theme={theme}
          w={420}
        />
      )}

      {bookCrushed && (
        <StampBanner
          x={540}
          y={560}
          at={Math.round(36.2 * fps)}
          text="তত্ত্ব বস্তার নিচে চাপা!"
          status="warn"
          theme={theme}
          w={460}
        />
      )}
    </g>
  );
};

// ══════════════════════════════════════════════════════════════════════════
// দৃশ্য ২ (০:৪০.৫ - ১:৩৬.৫): সাধারণ স্থির কপিকল (যান্ত্রিক সুবিধা = ১)
// ══════════════════════════════════════════════════════════════════════════
export const Scene2FixedPulley: React.FC<{ theme: Theme; layout: Layout }> = ({ theme }) => {
  const f = useCurrentFrame();
  const { fps } = useVideoConfig();
  const t = (f + 40.5 * fps) / fps; // গ্লোবাল টাইম (৪০.৫s থেকে ৯৬.৫s)

  const groundY = 1180;
  const roofY = 460;
  const pulleyX = 520;
  const pulleyY = roofY + 35;
  const sackX = 465;
  const ropeRightX = 575;
  const rafiX = 650;

  // ৫৪.৫s থেকে ৬১.৩s: রাফি নিচের দিকে টান দেয়, বস্তা বিঘতখানেক (৮৫px) ওপরে ওঠে
  // ৬১.৩s থেকে ৭৫.১s: হাতের পেশি কাঁপে (৫০ কেজি সমান বল)
  // ৭৫.১s থেকে ৭৯.০s: দ্রুত বস্তা মাটিতে নামিয়ে দেয়
  let liftPx = 0;
  if (t >= 55.0 && t < 75.2) {
    liftPx = interpolate(t, [55.0, 59.5], [0, 95], { extrapolateLeft: "clamp", extrapolateRight: "clamp" });
  } else if (t >= 75.2 && t < 78.5) {
    liftPx = interpolate(t, [75.2, 77.5], [95, 0], { extrapolateLeft: "clamp", extrapolateRight: "clamp" });
  }

  const isShaking = t >= 61.3 && t < 75.2;
  const showFormula = t >= 81.9;
  const spinDeg = liftPx * 2.2;

  return (
    <g>
      {/* মাঝের স্তর: দোতলা বাড়ি ও বিকেলের নরম রোদ */}
      <circle cx={900} cy={380} r={68} fill={theme.warn} opacity={0.22} />
      <TwoStoryHouse theme={theme} groundY={groundY} floor1Y={820} roofY={roofY} buildingX={100} buildingW={330} dim={showFormula} />

      <line x1={60} y1={groundY} x2={1020} y2={groundY} stroke={theme.text} strokeWidth={5} strokeLinecap="round" />

      {/* দড়ি: বস্তা থেকে স্থির কপিকলের ওপর দিয়ে রাফির হাতে */}
      <line
        x1={sackX}
        y1={pulleyY}
        x2={sackX}
        y2={groundY - 125 - liftPx}
        stroke={theme.accent}
        strokeWidth={7}
      />
      <line
        x1={ropeRightX}
        y1={pulleyY}
        x2={rafiX - 25}
        y2={groundY - 190 + liftPx * 0.6}
        stroke={theme.accent}
        strokeWidth={7}
      />

      {/* ছাদের কার্নিশে বাঁধা লোহার চাকা (স্থির কপিকল) */}
      <PopIn at={Math.round(2.0 * fps)} x={pulleyX} y={pulleyY}>
        <PulleyWheel
          theme={theme}
          r={54}
          spinDeg={spinDeg}
          lit={t < 54 || showFormula}
          label="স্থির কপিকল"
        />
      </PopIn>

      {/* সিমেন্টের বস্তা */}
      <g transform={`translate(${sackX} ${groundY - liftPx})`}>
        <CementSack theme={theme} scale={1.12} bad={isShaking} lit={liftPx > 10} label="৫০ কেজি" />
      </g>

      {/* রাফি দড়ি টানছে / চশমা ঠেলে তুলছে */}
      <g transform={`translate(${rafiX} ${groundY})`}>
        <Idle amp={2.5} speed={2.5}>
          <RafiPerson
            pose={showFormula ? "point" : "pull"}
            theme={theme}
            scale={1.35}
            sweat={isShaking}
            redPalm={isShaking}
            shake={isShaking ? 5 : 0}
          />
        </Idle>
      </g>

      {/* টানের দিক ও বস্তার ওঠার তীর */}
      {t >= 55.0 && (
        <>
          <ForceArrow
            x={sackX - 115}
            y1={groundY - 40}
            y2={groundY - 220}
            at={Math.round(14.5 * fps)}
            color={theme.data}
            label="ভার: ৫০ কেজি"
            theme={theme}
          />
          <ForceArrow
            x={rafiX + 110}
            y1={groundY - 280}
            y2={groundY - 90}
            at={Math.round(15.5 * fps)}
            color={isShaking ? theme.bad : theme.accent}
            label="টান: ৫০ কেজি"
            theme={theme}
          />
        </>
      )}

      {/* সংখ্যার চিপ ও যান্ত্রিক সুবিধা = ১ কার্ড */}
      {t >= 67.5 && (
        <MetricChip
          x={830}
          y={620}
          at={Math.round(27.0 * fps)}
          value="৫০ = ৫০"
          unit="প্রযুক্ত বল = ভার (কেজি)"
          status="bad"
          theme={theme}
          w={300}
        />
      )}

      {showFormula && (
        <g transform="translate(540 820)" opacity={clamp01((t - 82) * 3)}>
          <rect x={-320} y={-95} width={640} height={190} rx={24} fill={theme.surfaceHi} stroke={theme.accent} strokeWidth={4} />
          <text x={0} y={-32} textAnchor="middle" fill={theme.text} fontFamily={FONT_BENGALI} fontWeight={700} fontSize={32}>
            শুধু টানের দিক বদলেছে (ওপর → নিচ)
          </text>
          <text x={0} y={24} textAnchor="middle" fill={theme.accent} fontFamily={FONT_BENGALI} fontWeight={700} fontSize={44}>
            যান্ত্রিক সুবিধা = ১
          </text>
          <text x={0} y={68} textAnchor="middle" fill={theme.muted} fontFamily={FONT_BENGALI} fontWeight={600} fontSize={24}>
            ওজনের ভার এক বিন্দুও কমেনি
          </text>
        </g>
      )}
    </g>
  );
};
