import { Easing } from "remotion";

export const SPRING = {
  pop:  { damping: 11, stiffness: 170, mass: 0.8 },
  soft: { damping: 20, stiffness: 120, mass: 1.0 },
  snap: { damping: 14, stiffness: 260, mass: 0.6 }
};

export const SMOOTH = Easing.bezier(0.22, 1, 0.36, 1);
export const INOUT  = Easing.bezier(0.65, 0, 0.35, 1);

export const clamp01 = (x: number) => Math.min(1, Math.max(0, x));
export const easeOut = (x: number) => 1 - Math.pow(1 - clamp01(x), 3);

export const secToFrame = (sec: number, fps = 30) => Math.round(sec * fps);
export const cueFrame = (wordStartSec: number, fps = 30) =>
  Math.max(0, Math.round((wordStartSec - 0.08) * fps));

export const toBn = (n: number | string) =>
  String(n).replace(/\d/g, (d) => "০১২৩৪৫৬৭৮৯"[Number(d)]);

export const countAt = (t: number, startSec: number, durSec: number, from: number, to: number) => {
  const p = clamp01((t - startSec) / durSec);
  return Math.round(from + (to - from) * easeOut(p));
};
