import React from "react";
import { useCurrentFrame, useVideoConfig, spring } from "remotion";
import { Theme } from "../theme";
import { SPRING, clamp01, easeOut } from "../motion";
import { FONT_BENGALI } from "../fonts";

// ── পুরো-বস্তুর গতি-র‍্যাপার (Mover, PopIn, Idle) ──
export const Mover: React.FC<{
  from: [number, number];
  to: [number, number];
  start: number;
  dur: number;
  bob?: number;
  tilt?: number;
  children?: React.ReactNode;
}> = ({ from, to, start, dur, bob = 0, tilt = 0, children }) => {
  const f = useCurrentFrame();
  const { fps } = useVideoConfig();
  const p = easeOut((f - start) / Math.max(1, dur));
  const moving = p > 0 && p < 1 ? 1 : 0;
  const t = f / fps;
  const x = from[0] + (to[0] - from[0]) * p;
  const y = from[1] + (to[1] - from[1]) * p + Math.sin(t * 10) * bob * moving;
  const rot = Math.sin(t * 10) * tilt * moving;
  return (
    <g transform={`translate(${x} ${y}) rotate(${rot})`}>
      {children}
    </g>
  );
};

export const PopIn: React.FC<{
  at: number;
  x?: number;
  y?: number;
  children?: React.ReactNode;
}> = ({ at, x = 0, y = 0, children }) => {
  const f = useCurrentFrame();
  const { fps } = useVideoConfig();
  const p = spring({ frame: f - at, fps, config: SPRING.pop });
  const op = clamp01(p);
  const dy = (1 - p) * 60;
  const sc = 0.88 + 0.12 * p;
  return (
    <g opacity={op} transform={`translate(${x} ${y + dy}) scale(${sc})`}>
      {children}
    </g>
  );
};

export const Idle: React.FC<{
  amp?: number;
  speed?: number;
  tiltAmp?: number;
  children?: React.ReactNode;
}> = ({ amp = 3, speed = 2.2, tiltAmp = 0, children }) => {
  const f = useCurrentFrame();
  const { fps } = useVideoConfig();
  const t = f / fps;
  const dy = Math.sin(t * speed) * amp;
  const rot = tiltAmp ? Math.cos(t * speed) * tiltAmp : 0;
  return <g transform={`translate(0 ${dy}) rotate(${rot})`}>{children}</g>;
};

// ── রাফি (আইকন-মানুষ, চশমাসহ; অরিজিন (0,0) = পায়ের তলার মাঝ; পুরো-বস্তু পজের স্থির রূপ) ──
export type RafiPose = "pull" | "pant" | "point" | "happy" | "study";

export const RafiPerson: React.FC<{
  pose?: RafiPose;
  theme: Theme;
  scale?: number;
  sweat?: boolean;
  redPalm?: boolean;
  shake?: number;
}> = ({ pose = "pull", theme, scale = 1.35, sweat = false, redPalm = false, shake = 0 }) => {
  const f = useCurrentFrame();
  const { fps } = useVideoConfig();
  const t = f / fps;
  const jitterX = shake > 0 ? Math.sin(f * 1.9) * shake : 0;
  const jitterY = shake > 0 ? Math.cos(f * 2.3) * (shake * 0.5) : 0;
  const S = {
    stroke: theme.text,
    strokeWidth: 4,
    strokeLinejoin: "round" as const,
    strokeLinecap: "round" as const
  };
  const skin = "#E5B887";
  const cloth = theme.flow;
  const pants = theme.surfaceHi;
  const hair = theme.bg;

  const tiltBody = pose === "pant" ? 14 : pose === "pull" ? -8 : 0;

  return (
    <g transform={`translate(${jitterX} ${jitterY}) scale(${scale}) rotate(${tiltBody})`}>
      {/* পা দুটো */}
      <rect x={-24} y={-74} width={20} height={74} rx={9} fill={pants} {...S} />
      <rect x={4} y={-74} width={20} height={74} rx={9} fill={pants} {...S} />

      {/* হাতের স্থির রূপ (pose অনুযায়ী) */}
      {pose === "pull" && (
        <>
          <path d="M -28 -130 L 28 -155 M 28 -130 L 38 -142" stroke={theme.text} strokeWidth={20} strokeLinecap="round" fill="none" />
          <path d="M -28 -130 L 28 -155 M 28 -130 L 38 -142" stroke={skin} strokeWidth={13} strokeLinecap="round" fill="none" />
          <circle cx={32} cy={-150} r={11} fill={redPalm ? theme.bad : skin} {...S} />
        </>
      )}
      {pose === "pant" && (
        <>
          <path d="M -28 -126 L -18 -76 M 28 -126 L 18 -76" stroke={theme.text} strokeWidth={20} strokeLinecap="round" fill="none" />
          <path d="M -28 -126 L -18 -76 M 28 -126 L 18 -76" stroke={skin} strokeWidth={13} strokeLinecap="round" fill="none" />
        </>
      )}
      {pose === "point" && (
        <>
          <rect x={-48} y={-136} width={16} height={66} rx={8} fill={skin} {...S} />
          <path d="M 28 -126 L 86 -168" stroke={theme.text} strokeWidth={20} strokeLinecap="round" fill="none" />
          <path d="M 28 -126 L 86 -168" stroke={skin} strokeWidth={13} strokeLinecap="round" fill="none" />
        </>
      )}
      {pose === "happy" && (
        <>
          <path d="M -30 -128 L -64 -174 M 30 -128 L 64 -174" stroke={theme.text} strokeWidth={20} strokeLinecap="round" fill="none" />
          <path d="M -30 -128 L -64 -174 M 30 -128 L 64 -174" stroke={skin} strokeWidth={13} strokeLinecap="round" fill="none" />
        </>
      )}
      {pose === "study" && (
        <>
          <path d="M -28 -124 L 0 -98 M 28 -124 L 12 -98" stroke={theme.text} strokeWidth={20} strokeLinecap="round" fill="none" />
          <path d="M -28 -124 L 0 -98 M 28 -124 L 12 -98" stroke={skin} strokeWidth={13} strokeLinecap="round" fill="none" />
        </>
      )}

      {/* ধড় */}
      <rect x={-34} y={-144} width={68} height={78} rx={24} fill={cloth} {...S} />

      {/* মাথা */}
      <circle cx={0} cy={-176} r={32} fill={skin} {...S} />
      <path d="M -32 -180 Q -30 -214 0 -214 Q 30 -214 32 -180 Q 12 -196 -32 -180 Z" fill={hair} {...S} strokeWidth={3} />

      {/* চশমা (স্বচ্ছ ফ্রেম ও কাচ) */}
      <rect x={-24} y={-184} width={20} height={14} rx={4} fill="rgba(56, 189, 248, 0.22)" stroke={theme.text} strokeWidth={3} />
      <rect x={4} y={-184} width={20} height={14} rx={4} fill="rgba(56, 189, 248, 0.22)" stroke={theme.text} strokeWidth={3} />
      <line x1={-4} y1={-177} x2={4} y2={-177} stroke={theme.text} strokeWidth={3} />

      {/* মুখের ভাব */}
      {pose === "happy" ? (
        <path d="M -10 -158 Q 0 -148 10 -158" stroke={theme.bg} strokeWidth={3.5} fill="none" strokeLinecap="round" />
      ) : pose === "pant" || shake > 0 ? (
        <circle cx={0} cy={-156} r={5} fill={theme.bad} />
      ) : (
        <line x1={-8} y1={-156} x2={8} y2={-156} stroke={theme.bg} strokeWidth={3.5} strokeLinecap="round" />
      )}

      {/* কপালের ঘাম বিন্দু */}
      {sweat && (
        <g transform={`translate(28 ${-188 + ((t * 24) % 18)})`} opacity={0.9}>
          <path d="M 0 -8 C 5 -2 6 4 0 8 C -6 4 -5 -2 0 -8 Z" fill={theme.data} stroke={theme.text} strokeWidth={2} />
        </g>
      )}
    </g>
  );
};

// ── ৫০ কেজির সিমেন্টের বস্তা: অরিজিন (0,0) = বস্তার নিচের মাঝ ──
export const CementSack: React.FC<{
  theme: Theme;
  scale?: number;
  lit?: boolean;
  warn?: boolean;
  bad?: boolean;
  label?: string;
}> = ({ theme, scale = 1, lit = false, warn = false, bad = false, label = "৫০ কেজি" }) => {
  const borderCol = bad ? theme.bad : warn ? theme.warn : lit ? theme.accent : theme.text;
  const fillCol = bad ? "rgba(232, 72, 56, 0.22)" : lit ? theme.surfaceHi : theme.surface;

  return (
    <g transform={`scale(${scale})`}>
      {/* গ্লো */}
      {(lit || bad || warn) && (
        <ellipse cx={0} cy={-65} rx={105} ry={78} fill={borderCol} opacity={0.18} />
      )}
      {/* বস্তার কান/বাঁধন */}
      <path d="M -32 -128 L -46 -146 L -14 -136 Z" fill={fillCol} stroke={borderCol} strokeWidth={4} strokeLinejoin="round" />
      <path d="M 32 -128 L 46 -146 L 14 -136 Z" fill={fillCol} stroke={borderCol} strokeWidth={4} strokeLinejoin="round" />
      {/* বস্তার মূল বডি */}
      <rect x={-82} y={-130} width={164} height={130} rx={28} fill={fillCol} stroke={borderCol} strokeWidth={4.5} />
      {/* বস্তার সেলাই ও ব্যান্ড */}
      <line x1={-76} y1={-96} x2={76} y2={-96} stroke={theme.border} strokeWidth={3} strokeDasharray="10 8" />
      <line x1={-76} y1={-34} x2={76} y2={-34} stroke={theme.border} strokeWidth={3} strokeDasharray="10 8" />
      <rect x={-64} y={-86} width={128} height={44} rx={10} fill={theme.bg} stroke={borderCol} strokeWidth={2.5} />
      <text
        x={0}
        y={-56}
        textAnchor="middle"
        fill={bad ? theme.bad : lit ? theme.accent : theme.text}
        fontFamily={FONT_BENGALI}
        fontWeight={700}
        fontSize={30}
      >
        {label}
      </text>
      <text
        x={0}
        y={-12}
        textAnchor="middle"
        fill={theme.muted}
        fontFamily={FONT_BENGALI}
        fontWeight={600}
        fontSize={18}
      >
        সিমেন্ট
      </text>
    </g>
  );
};

// ── কপিকল (Pulley Wheel): অরিজিন (0,0) = চাকার কেন্দ্র ──
export const PulleyWheel: React.FC<{
  theme: Theme;
  r?: number;
  spinDeg?: number;
  lit?: boolean;
  movable?: boolean;
  label?: string;
}> = ({ theme, r = 46, spinDeg = 0, lit = false, movable = false, label }) => {
  const ringCol = lit ? theme.accent : movable ? theme.good : theme.data;
  return (
    <g>
      {lit && <circle cx={0} cy={0} r={r + 18} fill={ringCol} opacity={0.18} />}
      {/* উপরের বা নিচের হুক ব্র্যাকেট */}
      <path
        d={movable ? `M 0 ${r - 8} L 0 ${r + 34}` : `M 0 ${-r - 36} L 0 ${-r + 8}`}
        stroke={theme.text}
        strokeWidth={7}
        strokeLinecap="round"
      />
      {/* বাইরের রিম ও খাঁজ */}
      <circle cx={0} cy={0} r={r} fill={theme.surfaceHi} stroke={ringCol} strokeWidth={5} />
      <circle cx={0} cy={0} r={r - 10} fill={theme.bg} stroke={theme.border} strokeWidth={2.5} />
      {/* ঘূর্ণায়মান স্পোক */}
      <g transform={`rotate(${spinDeg})`}>
        {[0, 60, 120].map((ang) => (
          <line
            key={ang}
            x1={-r + 12}
            y1={0}
            x2={r - 12}
            y2={0}
            stroke={ringCol}
            strokeWidth={4}
            transform={`rotate(${ang})`}
          />
        ))}
      </g>
      {/* অক্ষ/নাট */}
      <circle cx={0} cy={0} r={11} fill={ringCol} stroke={theme.bg} strokeWidth={3} />
      {/* ব্র্যাকেট ফ্রেম */}
      <rect x={-12} y={-r - 12} width={24} height={r + 18} rx={8} fill="none" stroke={theme.text} strokeWidth={4} />
      {label && (
        <g transform={`translate(${r + 18} 0)`}>
          <rect x={0} y={-22} width={160} height={44} rx={12} fill={theme.surfaceHi} stroke={ringCol} strokeWidth={2.5} />
          <text x={80} y={8} textAnchor="middle" fill={ringCol} fontFamily={FONT_BENGALI} fontWeight={700} fontSize={24}>
            {label}
          </text>
        </g>
      )}
    </g>
  );
};

// ── দোতলা বাড়ির কাঠামো ও ছাদের কার্নিশ: অরিজিন (0,0) = ভূমির বাঁ প্রান্ত ──
export const TwoStoryHouse: React.FC<{
  theme: Theme;
  groundY?: number;
  floor1Y?: number;
  roofY?: number;
  buildingX?: number;
  buildingW?: number;
  dim?: boolean;
}> = ({
  theme,
  groundY = 1180,
  floor1Y = 820,
  roofY = 460,
  buildingX = 120,
  buildingW = 340,
  dim = false
}) => {
  const f = useCurrentFrame();
  const h = groundY - roofY;
  const pulseOp = 0.45 + Math.sin(f / 25) * 0.12;

  return (
    <g opacity={dim ? 0.35 : 1}>
      {/* বাড়ির মূল দেয়াল */}
      <rect
        x={buildingX}
        y={roofY}
        width={buildingW}
        height={h}
        rx={8}
        fill={theme.surface}
        stroke={theme.text}
        strokeWidth={4}
      />
      {/* একতলার ছাদ / দোতলার মেঝে রেখা */}
      <line
        x1={buildingX}
        y1={floor1Y}
        x2={buildingX + buildingW + 30}
        y2={floor1Y}
        stroke={theme.muted}
        strokeWidth={4}
        strokeDasharray="12 8"
      />
      {/* ছাদের কার্নিশ ও বাঁশের আউটরিগার বীম */}
      <rect
        x={buildingX - 20}
        y={roofY - 22}
        width={buildingW + 260}
        height={24}
        rx={6}
        fill={theme.surfaceHi}
        stroke={theme.text}
        strokeWidth={4}
      />
      {/* ছাদের রেলিং */}
      <rect
        x={buildingX + 12}
        y={roofY - 62}
        width={buildingW - 24}
        height={40}
        fill="none"
        stroke={theme.muted}
        strokeWidth={3}
      />
      {/* দোতলার জানালা (উষ্ণ আলোর ঝিকিমিকি) */}
      <rect x={buildingX + 45} y={roofY + 70} width={85} height={110} rx={8} fill={theme.bg} stroke={theme.text} strokeWidth={3.5} />
      <rect x={buildingX + 53} y={roofY + 78} width={69} height={94} rx={4} fill={theme.warn} opacity={pulseOp} />
      <rect x={buildingX + 185} y={roofY + 70} width={85} height={110} rx={8} fill={theme.bg} stroke={theme.text} strokeWidth={3.5} />
      <rect x={buildingX + 193} y={roofY + 78} width={69} height={94} rx={4} fill="rgba(255,255,255,0.08)" />

      {/* একতলার জানালা ও সিঁড়ির রেলিং */}
      <rect x={buildingX + 45} y={floor1Y + 70} width={85} height={110} rx={8} fill={theme.bg} stroke={theme.text} strokeWidth={3.5} />
      <rect x={buildingX + 53} y={floor1Y + 78} width={69} height={94} rx={4} fill={theme.warn} opacity={pulseOp * 0.8} />
      {/* সিঁড়ির রেলিং (দৃশ্য ৫-এ পা দিয়ে ঠেকানোর জন্য) */}
      <g transform={`translate(${buildingX + 185} ${floor1Y + 85})`}>
        <rect x={0} y={0} width={115} height={95} rx={6} fill={theme.bg} stroke={theme.text} strokeWidth={3.5} />
        {[-30, -10, 10, 30].map((dx, i) => (
          <line key={i} x1={55 + dx} y1={6} x2={55 + dx} y2={89} stroke={theme.muted} strokeWidth={3} />
        ))}
      </g>

      {/* তলার উচ্চতা লেবেল */}
      <text x={buildingX + 24} y={roofY + 38} fill={theme.muted} fontFamily={FONT_BENGALI} fontWeight={600} fontSize={22}>
        দোতলার ছাদ (২০ ফুট)
      </text>
      <text x={buildingX + 24} y={floor1Y + 38} fill={theme.muted} fontFamily={FONT_BENGALI} fontWeight={600} fontSize={22}>
        একতলা (১০ ফুট)
      </text>
    </g>
  );
};

// ── পানির ট্যাংক (ছাদের ওপর নতুন পানির ট্যাংক): অরিজিন (0,0) = নিচের মাঝ ──
export const WaterTank: React.FC<{ theme: Theme; scale?: number; lit?: boolean }> = ({
  theme,
  scale = 1,
  lit = false
}) => {
  const col = lit ? theme.data : theme.text;
  return (
    <g transform={`scale(${scale})`}>
      <rect x={-58} y={-115} width={116} height={115} rx={18} fill={theme.surfaceHi} stroke={col} strokeWidth={4} />
      <rect x={-28} y={-130} width={56} height={16} rx={5} fill={col} />
      {[-85, -58, -32].map((y) => (
        <line key={y} x1={-54} y1={y} x2={54} y2={y} stroke={theme.data} strokeWidth={3} opacity={0.65} />
      ))}
      <text x={0} y={-48} textAnchor="middle" fill={theme.data} fontFamily={FONT_BENGALI} fontWeight={700} fontSize={20}>
        পানির ট্যাংক
      </text>
    </g>
  );
};

// ── পদার্থবিজ্ঞান বই ও সূত্রের কার্ড: অরিজিন (0,0) = কেন্দ্র ──
export const PhysicsBookCard: React.FC<{ theme: Theme; scale?: number }> = ({ theme, scale = 1 }) => {
  return (
    <g transform={`scale(${scale})`}>
      <rect x={-190} y={-110} width={380} height={220} rx={22} fill={theme.surfaceHi} stroke={theme.accent} strokeWidth={4} />
      <line x1={0} y1={-102} x2={0} y2={102} stroke={theme.border} strokeWidth={3} />
      <text x={-95} y={-55} textAnchor="middle" fill={theme.accent} fontFamily={FONT_BENGALI} fontWeight={700} fontSize={26}>
        পদার্থবিজ্ঞান
      </text>
      <text x={-95} y={-10} textAnchor="middle" fill={theme.text} fontFamily={FONT_BENGALI} fontWeight={600} fontSize={22}>
        এসএসসি পরীক্ষা
      </text>
      <rect x={-155} y={22} width={120} height={46} rx={10} fill={theme.bg} stroke={theme.data} strokeWidth={2} />
      <text x={-95} y={53} textAnchor="middle" fill={theme.data} fontFamily={FONT_BENGALI} fontWeight={700} fontSize={24}>
        W = F × d
      </text>

      <text x={95} y={-45} textAnchor="middle" fill={theme.text} fontFamily={FONT_BENGALI} fontWeight={700} fontSize={24}>
        যান্ত্রিক সুবিধা
      </text>
      <rect x={25} y={-18} width={140} height={78} rx={12} fill={theme.bg} stroke={theme.accent} strokeWidth={2.5} />
      <text x={95} y={16} textAnchor="middle" fill={theme.accent} fontFamily={FONT_BENGALI} fontWeight={700} fontSize={24}>
        MA = ভার ÷ বল
      </text>
      <text x={95} y={48} textAnchor="middle" fill={theme.muted} fontFamily={FONT_BENGALI} fontWeight={600} fontSize={20}>
        অঙ্ক ও তত্ত্ব
      </text>
    </g>
  );
};

// ── টুলবক্স: অরিজিন (0,0) = নিচের মাঝ ──
export const Toolbox: React.FC<{ theme: Theme; open?: boolean; scale?: number }> = ({
  theme,
  open = false,
  scale = 1
}) => {
  return (
    <g transform={`scale(${scale})`}>
      <rect x={-68} y={-64} width={136} height={64} rx={12} fill={theme.surfaceHi} stroke={theme.warn} strokeWidth={4} />
      <path d="M -26 -64 L -26 -82 L 26 -82 L 26 -64" fill="none" stroke={theme.text} strokeWidth={4} strokeLinejoin="round" />
      <line x1={-66} y1={-36} x2={66} y2={-36} stroke={theme.warn} strokeWidth={3} />
      <rect x={-14} y={-44} width={28} height={16} rx={4} fill={theme.warn} />
      {open && (
        <circle cx={0} cy={-96} r={18} fill={theme.good} opacity={0.35} />
      )}
    </g>
  );
};
