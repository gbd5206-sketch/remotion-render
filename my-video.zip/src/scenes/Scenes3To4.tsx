import React from "react";
import { useCurrentFrame, useVideoConfig, interpolate } from "remotion";
import { Theme } from "../theme";
import { Layout } from "../layout";
import {
  RafiPerson,
  CementSack,
  PulleyWheel,
  TwoStoryHouse,
  Toolbox,
  PopIn,
  Idle
} from "../art/Kit";
import {
  MetricChip,
  StampBanner,
  VerticalRuler,
  ForceArrow,
  RingPulse
} from "../components/Annotations";
import { clamp01 } from "../motion";
import { FONT_BENGALI } from "../fonts";

// ══════════════════════════════════════════════════════════════════════════
// দৃশ্য ৩ (১:৩৬.৫ - ২:২৪.০): চলনশীল ও স্থির কপিকলের সমন্বয় (যান্ত্রিক সুবিধা = ২)
// ══════════════════════════════════════════════════════════════════════════
export const Scene3CompoundPulley: React.FC<{ theme: Theme; layout: Layout }> = ({ theme }) => {
  const f = useCurrentFrame();
  const { fps } = useVideoConfig();
  const t = (f + 96.5 * fps) / fps; // গ্লোবাল টাইম (৯৬.৫s থেকে ১৪৪.০s)

  const groundY = 1180;
  const roofY = 460;
  const fixedPulleyX = 560;
  const fixedPulleyY = roofY + 35;
  const movablePulleyX = 480;
  const anchorX = 435;
  const rafiX = 710;

  // ১২০.০s থেকে ১৪৪.০s: রাফি টান দেয়, মুখে হাসি ফোটে, বস্তা ও চলনশীল কপিকল একসাথে ওপরে ওঠে
  const liftProgress = clamp01((t - 120.0) / 18.0);
  const liftPx = liftProgress * 240;
  const movableY = groundY - 190 - liftPx;
  const spinDeg = liftPx * 2.5;

  const showSplitWeight = t >= 129.5;
  const showHalfForce = t >= 136.5;

  return (
    <g>
      <TwoStoryHouse theme={theme} groundY={groundY} floor1Y={820} roofY={roofY} buildingX={90} buildingW={320} />

      <line x1={60} y1={groundY} x2={1020} y2={groundY} stroke={theme.text} strokeWidth={5} strokeLinecap="round" />

      {/* টুলবক্স (পাশে রাখা, যেখান থেকে দ্বিতীয় কপিকল বের করা হলো) */}
      <PopIn at={Math.round(0.5 * fps)} x={880} y={groundY}>
        <Toolbox theme={theme} open={t >= 98.0} scale={1.1} />
      </PopIn>

      {/* দড়ির ৩টি অংশ: ১. ছাদের বাঁশ থেকে চলনশীল কপিকলের বাঁ দিক, ২. চলনশীল থেকে স্থির কপিকল, ৩. স্থির কপিকল থেকে রাফির হাত */}
      {t >= 109.0 && (
        <g>
          {/* বাঁ অংশের দড়ি (২৫ কেজি ভার বহন করে) */}
          <line
            x1={anchorX}
            y1={roofY + 2}
            x2={anchorX}
            y2={movableY}
            stroke={ showSplitWeight ? theme.good : theme.accent }
            strokeWidth={7}
          />
          <circle cx={anchorX} cy={roofY + 2} r={9} fill={theme.accent} />

          {/* ডান অংশের দড়ি (২৫ কেজি ভার বহন করে) */}
          <line
            x1={movablePulleyX + 45}
            y1={movableY}
            x2={fixedPulleyX - 45}
            y2={fixedPulleyY}
            stroke={ showSplitWeight ? theme.good : theme.accent }
            strokeWidth={7}
          />

          {/* রাফির হাতের অংশের দড়ি */}
          <line
            x1={fixedPulleyX + 48}
            y1={fixedPulleyY}
            x2={rafiX - 28}
            y2={groundY - 195}
            stroke={theme.accent}
            strokeWidth={7}
            strokeDasharray="16 6"
            strokeDashoffset={-f * 2.2}
          />
        </g>
      )}

      {/* উপরের স্থির কপিকল */}
      <g transform={`translate(${fixedPulleyX} ${fixedPulleyY})`}>
        <PulleyWheel theme={theme} r={48} spinDeg={spinDeg} lit={t >= 116} label="স্থির কপিকল" />
      </g>

      {/* নিচের চলনশীল কপিকল (বস্তার সাথে সাথে ওপরে ওঠে) */}
      <PopIn at={Math.round(4.0 * fps)} x={movablePulleyX} y={movableY}>
        <PulleyWheel
          theme={theme}
          r={45}
          spinDeg={-spinDeg}
          movable={true}
          lit={t >= 115}
          label="চলনশীল কপিকল"
        />
      </PopIn>

      {/* ৫০ কেজির সিমেন্টের বস্তা */}
      <g transform={`translate(${movablePulleyX} ${groundY - liftPx})`}>
        <CementSack theme={theme} scale={1.1} lit={liftPx > 15} label="৫০ কেজি" />
      </g>

      {/* রাফি (হাসিমুখে অনায়াসে দড়ি টানছে) */}
      <g transform={`translate(${rafiX} ${groundY})`}>
        <Idle amp={3} speed={2.6}>
          <RafiPerson
            pose={t >= 122.0 ? "happy" : "pull"}
            theme={theme}
            scale={1.36}
            sweat={false}
          />
        </Idle>
      </g>

      {/* ওজন সমান দুই ভাগে ভাগ (২৫ কেজি + ২৫ কেজি) */}
      {showSplitWeight && (
        <>
          <MetricChip
            x={260}
            y={640}
            at={Math.round(33.0 * fps)}
            value="২৫ কেজি"
            unit="১ম দড়ির অংশ"
            status="good"
            theme={theme}
            w={230}
          />
          <MetricChip
            x={830}
            y={640}
            at={Math.round(33.8 * fps)}
            value="২৫ কেজি"
            unit="২য় দড়ির অংশ"
            status="good"
            theme={theme}
            w={230}
          />
        </>
      )}

      {showHalfForce && (
        <>
          <MetricChip
            x={830}
            y={820}
            at={Math.round(40.2 * fps)}
            value="২৫ কেজি টান"
            unit="৫০ কেজি বস্তা উঠছে!"
            status="accent"
            theme={theme}
            w={270}
          />
          <StampBanner
            x={540}
            y={360}
            at={Math.round(39.0 * fps)}
            text="✓ যান্ত্রিক সুবিধা = ২ (দ্বিগুণ)"
            status="good"
            theme={theme}
            w={500}
          />
        </>
      )}
    </g>
  );
};

// ══════════════════════════════════════════════════════════════════════════
// দৃশ্য ৪ (২:২৪.০ - ৩:১৮.২): মাঝপথে (১০ ফুট) দড়ি শেষ ও শক্তির নিত্যতা সূত্র
// ══════════════════════════════════════════════════════════════════════════
export const Scene4RopeShortageAndEnergyLaw: React.FC<{ theme: Theme; layout: Layout }> = ({ theme }) => {
  const f = useCurrentFrame();
  const { fps } = useVideoConfig();
  const t = (f + 144.0 * fps) / fps; // গ্লোবাল টাইম (১৪৪.০s থেকে ১৯৮.২s)

  const groundY = 1180;
  const floor1Y = 820; // ১০ ফুট উচ্চতা (একতলার জানালার সমান)
  const roofY = 460;   // ২০ ফুট উচ্চতা (দোতলার ছাদ)
  const fixedPulleyX = 560;
  const fixedPulleyY = roofY + 35;
  const movablePulleyX = 480;
  const anchorX = 435;
  const rafiX = 720;

  // বস্তা ঠিক একতলার জানালার সমান উচ্চতায় (১০ ফুট = floor1Y) উঠে মাঝপথে ঝুলে থাকে
  const sackBottomY = floor1Y;
  const movableY = sackBottomY - 190;

  const isRopeEndAlert = t >= 153.5;
  const showRulers = t >= 158.0;
  const showEnergyCard = t >= 179.0;

  return (
    <g>
      <TwoStoryHouse
        theme={theme}
        groundY={groundY}
        floor1Y={floor1Y}
        roofY={roofY}
        buildingX={90}
        buildingW={310}
        dim={showEnergyCard}
      />

      <line x1={60} y1={groundY} x2={1020} y2={groundY} stroke={theme.text} strokeWidth={5} strokeLinecap="round" />

      {/* দড়ির ব্যবস্থা */}
      <line x1={anchorX} y1={roofY + 2} x2={anchorX} y2={movableY} stroke={theme.accent} strokeWidth={7} />
      <line x1={movablePulleyX + 45} y1={movableY} x2={fixedPulleyX - 45} y2={fixedPulleyY} stroke={theme.accent} strokeWidth={7} />
      <line x1={fixedPulleyX + 48} y1={fixedPulleyY} x2={rafiX - 28} y2={groundY - 195} stroke={isRopeEndAlert ? theme.bad : theme.accent} strokeWidth={7} />

      {/* রাফির হাতে দড়ির শেষ প্রান্তে লাল সতর্ক পালস */}
      {isRopeEndAlert && (
        <g>
          <RingPulse x={rafiX - 28} y={groundY - 195} color={theme.bad} r={34} />
          <circle cx={rafiX - 28} cy={groundY - 195} r={10} fill={theme.bad} />
        </g>
      )}

      {/* স্থির ও চলনশীল কপিকল */}
      <g transform={`translate(${fixedPulleyX} ${fixedPulleyY})`}>
        <PulleyWheel theme={theme} r={48} spinDeg={180} />
      </g>
      <g transform={`translate(${movablePulleyX} ${movableY})`}>
        <PulleyWheel theme={theme} r={45} spinDeg={-180} movable={true} />
      </g>

      {/* মাঝপথে (১০ ফুট উচ্চতায়) শূন্যে ঝুলে থাকা বস্তা */}
      <g transform={`translate(${movablePulleyX} ${sackBottomY})`}>
        <Idle amp={4} speed={3.5} tiltAmp={1.5}>
          <CementSack theme={theme} scale={1.08} warn={isRopeEndAlert} label="৫০ কেজি" />
        </Idle>
      </g>

      {/* রাফি */}
      <g transform={`translate(${rafiX} ${groundY})`}>
        <Idle amp={2.5} speed={2.5}>
          <RafiPerson
            pose={showEnergyCard ? "point" : "pull"}
            theme={theme}
            scale={1.35}
            sweat={isRopeEndAlert && !showEnergyCard}
          />
        </Idle>
      </g>

      {/* রুলার: নিচে উঠেছে ১০ ফুট, ওপরে ছাদ এখনো ১০ ফুট বাকি */}
      {showRulers && (
        <>
          <VerticalRuler
            x={375}
            yTop={floor1Y}
            yBottom={groundY}
            at={Math.round(14.0 * fps)}
            label="উঠেছে: ১০ ফুট"
            color={theme.good}
            theme={theme}
          />
          <VerticalRuler
            x={375}
            yTop={roofY}
            yBottom={floor1Y}
            at={Math.round(21.0 * fps)}
            label="বাকি: ১০ ফুট"
            color={theme.bad}
            theme={theme}
          />
          <MetricChip
            x={850}
            y={640}
            at={Math.round(15.0 * fps)}
            value="২০ ফুট দড়ি"
            unit="টেনে শেষ প্রান্ত হাতে!"
            status="bad"
            theme={theme}
            w={270}
          />
        </>
      )}

      {/* শক্তির নিত্যতা সূত্রের হিসাব কার্ড (১৭৯.০s থেকে ১৯৮.২s) */}
      {showEnergyCard && (
        <g transform="translate(540 880)" opacity={clamp01((t - 179.0) * 3)}>
          <rect x={-370} y={-130} width={740} height={260} rx={26} fill={theme.surfaceHi} stroke={theme.data} strokeWidth={4} />
          <text x={0} y={-68} textAnchor="middle" fill={theme.data} fontFamily={FONT_BENGALI} fontWeight={700} fontSize={34}>
            শক্তির নিত্যতা সূত্র (কাজ অপরিবর্তিত)
          </text>
          <text x={0} y={-14} textAnchor="middle" fill={theme.text} fontFamily={FONT_BENGALI} fontWeight={700} fontSize={30}>
            বল অর্ধেক (১/২) হলে দূরত্ব দ্বিগুণ (২×) হবে
          </text>
          <rect x={-310} y={24} width={620} height={74} rx={16} fill={theme.bg} stroke={theme.accent} strokeWidth={3} />
          <text x={0} y={72} textAnchor="middle" fill={theme.accent} fontFamily={FONT_BENGALI} fontWeight={700} fontSize={34}>
            ১০ ফুট তুলতে দড়ি টানতে হবে = ২০ ফুট
          </text>
        </g>
      )}
    </g>
  );
};
