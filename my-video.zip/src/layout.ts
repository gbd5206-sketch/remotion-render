export const RATIOS = {
  "9:16": {
    w: 1080,
    h: 1920,
    margin: 70,
    tab: { y: 150, h: 62 },
    label: { y: 262 },
    stage: { top: 280, bottom: 1300 },
    caption: { y: 1398, font: 62, pillH: 115 },
    reserveFrom: 1500,
    k: 1,
    glowR: 700
  },
  "16:9": {
    w: 1920,
    h: 1080,
    margin: 100,
    tab: { y: 44, h: 56 },
    label: { y: 128 },
    stage: { top: 160, bottom: 850 },
    caption: { y: 940, font: 52, pillH: 100 },
    reserveFrom: 1000,
    k: 0.7,
    glowR: 850
  }
} as const;

export type RatioKey = keyof typeof RATIOS;
export type Layout = (typeof RATIOS)[RatioKey];

// এক জায়গায় রেশিও কনফিগ: "9:16" অথবা "16:9"
export const ACTIVE_RATIO: RatioKey = "9:16";
export const LAYOUT: Layout = RATIOS[ACTIVE_RATIO];

export const px = (L: { k: number }, n: number) => Math.round(n * L.k);
