import React from "react";
import {
  AbsoluteFill,
  Audio,
  Composition,
  Sequence,
  staticFile,
  useCurrentFrame,
  useVideoConfig,
  interpolate
} from "remotion";
import { THEME } from "./theme";
import { LAYOUT } from "./layout";
import { fontStyles } from "./fonts";
import { SCENES, STEP_TABS } from "./scenes";
import { Caption, StepHeader, ChunkItem } from "./components/Annotations";
import { Scene1Struggle, Scene2FixedPulley } from "./scenes/Scenes1To2";
import { Scene3CompoundPulley, Scene4RopeShortageAndEnergyLaw } from "./scenes/Scenes3To4";
import { Scene5FortyFootRopeSuccess, Scene6ConclusionAndLifeLesson } from "./scenes/Scenes5To6";
import timingData from "./timing.json";

const chunks = timingData.chunks as ChunkItem[];

// সাউন্ড ইফেক্ট কিউ তালিকা (শুধুমাত্র ইউজারের দেওয়া ZIP-এর সাউন্ড ইফেক্ট, পরিমিত ভলিউমে যাতে ভয়েস চাপা না পড়ে)
const SFX_EVENTS: { sec: number; file: string; vol: number }[] = [
  { sec: 8.6,   file: "assets/eritnhut1992-buzzer-or-wrong-answer-20582.mp3", vol: 0.25 },
  { sec: 22.3,  file: "assets/lenspulse-foley-paper-handling-amp-page-turning-sfx-584919.mp3", vol: 0.35 },
  { sec: 40.6,  file: "assets/dragon-studio-simple-whoosh-382724.mp3", vol: 0.32 },
  { sec: 47.0,  file: "assets/universfield-computer-mouse-click-352734.mp3", vol: 0.35 },
  { sec: 61.5,  file: "assets/u_31vnwfmzt6-error-126627.mp3", vol: 0.28 },
  { sec: 95.0,  file: "assets/u_31vnwfmzt6-error-126627.mp3", vol: 0.25 },
  { sec: 96.6,  file: "assets/dragon-studio-simple-whoosh-382724.mp3", vol: 0.32 },
  { sec: 116.5, file: "assets/freesound_community-bell-98033.mp3", vol: 0.30 },
  { sec: 136.8, file: "assets/universfield-computer-mouse-click-352734.mp3", vol: 0.35 },
  { sec: 144.1, file: "assets/dragon-studio-simple-whoosh-382724.mp3", vol: 0.30 },
  { sec: 154.0, file: "assets/eritnhut1992-buzzer-or-wrong-answer-20582.mp3", vol: 0.25 },
  { sec: 179.0, file: "assets/lenspulse-foley-paper-handling-amp-page-turning-sfx-584919.mp3", vol: 0.35 },
  { sec: 198.3, file: "assets/dragon-studio-simple-whoosh-382724.mp3", vol: 0.32 },
  { sec: 210.5, file: "assets/universfield-computer-mouse-click-352734.mp3", vol: 0.35 },
  { sec: 235.4, file: "assets/freesound_community-bell-98033.mp3", vol: 0.35 },
  { sec: 238.6, file: "assets/dragon-studio-simple-whoosh-382724.mp3", vol: 0.30 },
  { sec: 251.5, file: "assets/freesound_community-bell-98033.mp3", vol: 0.28 }
];

export const MainExplainerVideo: React.FC = () => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const t = frame / fps;

  const activeScene =
    SCENES.find((s) => t >= s.startSec && t < s.endSec) || SCENES[SCENES.length - 1];

  const glowOpacity = 0.13 + Math.sin(t * Math.PI) * 0.04;

  // দৃশ্য বদলের সময় পাতলা উল্লম্ব রেখার ওয়াইপ (০.৩ সেকেন্ড)
  const sceneLocalSec = t - activeScene.startSec;
  const wipeProgress = interpolate(sceneLocalSec, [0, 0.3], [0, 1], {
    extrapolateLeft: "clamp",
    extrapolateRight: "clamp"
  });

  return (
    <AbsoluteFill style={{ backgroundColor: THEME.bg, overflow: "hidden" }}>
      <style>{fontStyles}</style>

      {/* মূল ভয়েসওভার অডিও */}
      <Audio src={staticFile("voice.mp3")} />

      {/* ZIP থেকে সাউন্ড ইফেক্টস */}
      {SFX_EVENTS.map((sfx, idx) => (
        <Sequence key={idx} from={Math.round(sfx.sec * fps)} durationInFrames={Math.round(4 * fps)}>
          <Audio src={staticFile(sfx.file)} volume={sfx.vol} />
        </Sequence>
      ))}

      {/* ক্যানভাস SVG: ডট-গ্রিড, কেন্দ্র-গ্লো, ধাপ-ট্যাব বার এবং ৬টি দৃশ্য */}
      <svg
        width={LAYOUT.w}
        height={LAYOUT.h}
        viewBox={`0 0 ${LAYOUT.w} ${LAYOUT.h}`}
        style={{ position: "absolute", inset: 0 }}
      >
        <defs>
          <pattern id="bg-dot-grid" width={48} height={48} patternUnits="userSpaceOnUse">
            <circle cx={24} cy={24} r={2.5} fill={THEME.text} opacity={0.07} />
          </pattern>
          <radialGradient id="stage-center-glow" cx="50%" cy="45%" r="50%">
            <stop offset="0%" stopColor={THEME.data} stopOpacity={glowOpacity} />
            <stop offset="100%" stopColor={THEME.bg} stopOpacity={0} />
          </radialGradient>
        </defs>

        {/* পুরো ফ্রেম জুড়ে ডট-গ্রিড ও কেন্দ্রের গ্লো */}
        <rect width={LAYOUT.w} height={LAYOUT.h} fill="url(#bg-dot-grid)" />
        <circle cx={LAYOUT.w / 2} cy={790} r={LAYOUT.glowR} fill="url(#stage-center-glow)" />

        {/* ওপরে ধাপ-ট্যাব বার ও সাব-লেবেল */}
        <StepHeader
          steps={STEP_TABS}
          activeIndex={activeScene.stepTab}
          subLabel={activeScene.subLabel}
          theme={THEME}
          layout={LAYOUT}
        />

        {/* ৬টি দৃশ্যের Sequence */}
        <Sequence from={0} durationInFrames={Math.round(40.5 * fps)}>
          <Scene1Struggle theme={THEME} layout={LAYOUT} />
        </Sequence>

        <Sequence from={Math.round(40.5 * fps)} durationInFrames={Math.round((96.5 - 40.5) * fps)}>
          <Scene2FixedPulley theme={THEME} layout={LAYOUT} />
        </Sequence>

        <Sequence from={Math.round(96.5 * fps)} durationInFrames={Math.round((144.0 - 96.5) * fps)}>
          <Scene3CompoundPulley theme={THEME} layout={LAYOUT} />
        </Sequence>

        <Sequence from={Math.round(144.0 * fps)} durationInFrames={Math.round((198.2 - 144.0) * fps)}>
          <Scene4RopeShortageAndEnergyLaw theme={THEME} layout={LAYOUT} />
        </Sequence>

        <Sequence from={Math.round(198.2 * fps)} durationInFrames={Math.round((238.5 - 198.2) * fps)}>
          <Scene5FortyFootRopeSuccess theme={THEME} layout={LAYOUT} />
        </Sequence>

        <Sequence from={Math.round(238.5 * fps)} durationInFrames={7810 - Math.round(238.5 * fps)}>
          <Scene6ConclusionAndLifeLesson theme={THEME} layout={LAYOUT} />
        </Sequence>

        {/* দৃশ্য-বদলের উল্লম্ব data রেখার ওয়াইপ (০.৩s) */}
        {activeScene.id > 1 && wipeProgress < 1 && (
          <line
            x1={LAYOUT.w * wipeProgress}
            y1={LAYOUT.stage.top}
            x2={LAYOUT.w * wipeProgress}
            y2={LAYOUT.stage.bottom}
            stroke={THEME.data}
            strokeWidth={4}
            opacity={1 - wipeProgress}
          />
        )}
      </svg>

      {/* নিচে শব্দ-সিঙ্ক করা ক্যাপশন পিল */}
      <Caption chunks={chunks} theme={THEME} layout={LAYOUT} />
    </AbsoluteFill>
  );
};

export const RemotionRoot: React.FC = () => {
  return (
    <>
      <Composition
        id="KopikolExplainer"
        component={MainExplainerVideo}
        durationInFrames={7810}
        fps={30}
        width={LAYOUT.w}
        height={LAYOUT.h}
      />
    </>
  );
};
