import React from "react";
import { useCurrentFrame, useVideoConfig, interpolate, spring } from "remotion";
import { Theme } from "../theme";
import { Layout, px } from "../layout";
import { SPRING, clamp01 } from "../motion";
import { FONT_BENGALI } from "../fonts";

export interface WordItem {
  idx: number;
  cue: number;
  w: string;
  s: number;
  e: number;
}

export interface ChunkItem {
  words: WordItem[];
  start: number;
  end: number;
}

export function captionState(chunks: ChunkItem[], t: number, hold = 0.35) {
  for (let i = 0; i < chunks.length; i++) {
    const c = chunks[i];
    const next = chunks[i + 1];
    const until = next ? Math.min(next.start, c.end + hold) : c.end + hold;
    if (t >= c.start - 0.02 && t < until) {
      let active = 0;
      c.words.forEach((w, k) => {
        if (t >= w.s - 0.01) active = k;
      });
      return { chunk: c, active };
    }
  }
  return null;
}

// ── ক্যাপশন কম্পোনেন্ট (শব্দে-শব্দে হাইলাইট, রেশিও অনুযায়ী নির্দিষ্ট স্থানে) ──
export const Caption: React.FC<{
  chunks: ChunkItem[];
  theme: Theme;
  layout: Layout;
}> = ({ chunks, theme, layout }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const t = frame / fps;
  const st = captionState(chunks, t);
  if (!st) return null;

  const enter = interpolate(t - st.chunk.start, [0, 0.1], [0, 1], {
    extrapolateLeft: "clamp",
    extrapolateRight: "clamp"
  });

  return (
    <div
      style={{
        position: "absolute",
        left: layout.margin,
        right: layout.margin,
        top: layout.caption.y,
        transform: "translateY(-50%)",
        display: "flex",
        justifyContent: "center",
        opacity: enter,
        pointerEvents: "none",
        zIndex: 40
      }}
    >
      <div
        style={{
          display: "flex",
          flexWrap: "wrap",
          justifyContent: "center",
          alignItems: "center",
          gap: px(layout, 14),
          padding: `${px(layout, 16)}px ${px(layout, 28)}px`,
          minHeight: layout.caption.pillH,
          borderRadius: px(layout, 30),
          background: theme.surfaceHi,
          border: `2px solid ${theme.border}`,
          fontFamily: FONT_BENGALI,
          fontWeight: 700,
          fontSize: layout.caption.font,
          lineHeight: 1.15
        }}
      >
        {st.chunk.words.map((w, k) => {
          const on = k === st.active;
          const done = k < st.active;
          return (
            <span
              key={k}
              style={{
                padding: `${px(layout, 4)}px ${px(layout, 14)}px`,
                borderRadius: px(layout, 14),
                background: on ? theme.accent : "transparent",
                color: on ? theme.onAccent : done ? theme.text : theme.muted,
                opacity: on || done ? 1 : 0.55
              }}
            >
              {w.w}
            </span>
          );
        })}
      </div>
    </div>
  );
};

// ── ধাপ-ট্যাব বার (ওপরে ৩টি ক্যাপসুল + বাঁয়ে ধাপ লেবেল) ──
export const StepHeader: React.FC<{
  steps: string[];
  activeIndex: number;
  subLabel: string;
  theme: Theme;
  layout: Layout;
}> = ({ steps, activeIndex, subLabel, theme, layout }) => {
  return (
    <g>
      {/* ধাপ ট্যাব বার */}
      <foreignObject x={0} y={layout.tab.y} width={layout.w} height={layout.tab.h + 20}>
        <div
          style={{
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
            gap: px(layout, 12),
            width: "100%",
            height: layout.tab.h,
            fontFamily: FONT_BENGALI
          }}
        >
          {steps.map((st, idx) => {
            const isAct = idx === activeIndex;
            const isDone = idx < activeIndex;
            return (
              <div
                key={idx}
                style={{
                  display: "flex",
                  alignItems: "center",
                  gap: px(layout, 8),
                  padding: `0 ${px(layout, 22)}px`,
                  height: layout.tab.h,
                  borderRadius: px(layout, 31),
                  background: isAct ? theme.accent : theme.surfaceHi,
                  border: `1.5px solid ${isAct ? theme.accent : theme.border}`,
                  color: isAct ? theme.onAccent : isDone ? theme.text : theme.muted,
                  fontSize: px(layout, 27),
                  fontWeight: 700
                }}
              >
                {isDone && (
                  <span
                    style={{
                      width: px(layout, 10),
                      height: px(layout, 10),
                      borderRadius: "50%",
                      background: theme.good,
                      display: "inline-block"
                    }}
                  />
                )}
                <span>{st}</span>
              </div>
            );
          })}
        </div>
      </foreignObject>

      {/* ধাপ সাব-লেবেল */}
      <g transform={`translate(${layout.margin} ${layout.label.y})`}>
        <rect x={0} y={-16} width={px(layout, 36)} height={px(layout, 5)} rx={2.5} fill={theme.accent} />
        <text
          x={px(layout, 48)}
          y={-6}
          fill={theme.muted}
          fontFamily={FONT_BENGALI}
          fontWeight={600}
          fontSize={px(layout, 26)}
        >
          {subLabel}
        </text>
      </g>
    </g>
  );
};

// ── মেট্রিক চিপ (সংখ্যা + ইউনিট + গ্লো বর্ডার) ──
export const MetricChip: React.FC<{
  x: number;
  y: number;
  at: number;
  value: string;
  unit: string;
  status?: "accent" | "good" | "warn" | "bad" | "data";
  theme: Theme;
  w?: number;
}> = ({ x, y, at, value, unit, status = "accent", theme, w = 250 }) => {
  const f = useCurrentFrame();
  const { fps } = useVideoConfig();
  const p = spring({ frame: f - at, fps, config: SPRING.pop });
  if (f < at) return null;

  const col =
    status === "bad"
      ? theme.bad
      : status === "good"
      ? theme.good
      : status === "warn"
      ? theme.warn
      : status === "data"
      ? theme.data
      : theme.accent;

  const dy = (1 - p) * 35;
  const sc = 0.9 + 0.1 * p;

  return (
    <g opacity={clamp01(p)} transform={`translate(${x} ${y + dy}) scale(${sc})`}>
      <rect x={-w / 2 - 6} y={-48} width={w + 12} height={96} rx={26} fill={col} opacity={0.14} />
      <rect x={-w / 2} y={-42} width={w} height={84} rx={22} fill={theme.surface} stroke={col} strokeWidth={3} />
      <text
        x={0}
        y={-2}
        textAnchor="middle"
        fill={col}
        fontFamily={FONT_BENGALI}
        fontWeight={700}
        fontSize={44}
      >
        {value}
      </text>
      <text
        x={0}
        y={28}
        textAnchor="middle"
        fill={theme.muted}
        fontFamily={FONT_BENGALI}
        fontWeight={600}
        fontSize={22}
      >
        {unit}
      </text>
    </g>
  );
};

// ── স্ট্যাম্প / ব্যানার (✕ বা ✓ সহ) ──
export const StampBanner: React.FC<{
  x: number;
  y: number;
  at: number;
  text: string;
  status?: "bad" | "good" | "accent" | "warn";
  theme: Theme;
  w?: number;
}> = ({ x, y, at, text, status = "bad", theme, w = 360 }) => {
  const f = useCurrentFrame();
  const { fps } = useVideoConfig();
  const p = spring({ frame: f - at, fps, config: SPRING.pop });
  if (f < at) return null;

  const col =
    status === "good"
      ? theme.good
      : status === "accent"
      ? theme.accent
      : status === "warn"
      ? theme.warn
      : theme.bad;

  const sc = interpolate(p, [0, 1], [1.45, 1]);
  const rot = interpolate(p, [0, 1], [-7, -3]);

  return (
    <g opacity={clamp01(p)} transform={`translate(${x} ${y}) rotate(${rot}) scale(${sc})`}>
      <rect x={-w / 2 - 6} y={-44} width={w + 12} height={88} rx={18} fill={col} opacity={0.18} />
      <rect x={-w / 2} y={-38} width={w} height={76} rx={14} fill={theme.bg} stroke={col} strokeWidth={4} />
      <text
        x={0}
        y={13}
        textAnchor="middle"
        fill={col}
        fontFamily={FONT_BENGALI}
        fontWeight={700}
        fontSize={36}
      >
        {text}
      </text>
    </g>
  );
};

// ── রুলার / উচ্চতা মাপনী (১০ ফুট / ২০ ফুট) ──
export const VerticalRuler: React.FC<{
  x: number;
  yTop: number;
  yBottom: number;
  at: number;
  label: string;
  color: string;
  theme: Theme;
}> = ({ x, yTop, yBottom, at, label, color, theme }) => {
  const f = useCurrentFrame();
  const { fps } = useVideoConfig();
  const p = clamp01((f - at) / (fps * 0.6));
  if (f < at) return null;

  const curTop = yBottom - (yBottom - yTop) * p;
  const midY = (curTop + yBottom) / 2;
  const ticks = 8;

  return (
    <g opacity={clamp01(p * 2)}>
      <line x1={x} y1={yBottom} x2={x} y2={curTop} stroke={color} strokeWidth={4} />
      <line x1={x - 16} y1={yBottom} x2={x + 16} y2={yBottom} stroke={color} strokeWidth={4} />
      <line x1={x - 16} y1={curTop} x2={x + 16} y2={curTop} stroke={color} strokeWidth={4} />
      {Array.from({ length: ticks }).map((_, idx) => {
        const ty = yBottom - ((yBottom - curTop) * (idx + 1)) / (ticks + 1);
        return <line key={idx} x1={x - 8} y1={ty} x2={x + 8} y2={ty} stroke={color} strokeWidth={2.5} />;
      })}
      <g transform={`translate(${x - 95} ${midY})`}>
        <rect x={-75} y={-24} width={150} height={48} rx={14} fill={theme.bg} stroke={color} strokeWidth={3} />
        <text x={0} y={8} textAnchor="middle" fill={color} fontFamily={FONT_BENGALI} fontWeight={700} fontSize={26}>
          {label}
        </text>
      </g>
    </g>
  );
};

// ── বলের দিক নির্দেশক অ্যানিমেটেড তীর (Force Arrow) ──
export const ForceArrow: React.FC<{
  x: number;
  y1: number;
  y2: number;
  at: number;
  color: string;
  label?: string;
  theme: Theme;
}> = ({ x, y1, y2, at, color, label, theme }) => {
  const f = useCurrentFrame();
  const { fps } = useVideoConfig();
  const p = clamp01((f - at) / (fps * 0.45));
  if (f < at) return null;

  const curY2 = y1 + (y2 - y1) * p;
  const dir = y2 > y1 ? 1 : -1;

  return (
    <g opacity={clamp01(p * 2)}>
      <line
        x1={x}
        y1={y1}
        x2={x}
        y2={curY2}
        stroke={color}
        strokeWidth={6}
        strokeDasharray="14 8"
        strokeDashoffset={-f * 1.8 * dir}
      />
      <polygon
        points={`${x},${curY2 + 12 * dir} ${x - 14},${curY2 - 12 * dir} ${x + 14},${curY2 - 12 * dir}`}
        fill={color}
      />
      {label && (
        <g transform={`translate(${x + 95} ${(y1 + curY2) / 2})`}>
          <rect x={-75} y={-22} width={150} height={44} rx={12} fill={theme.surfaceHi} stroke={color} strokeWidth={2.5} />
          <text x={0} y={8} textAnchor="middle" fill={color} fontFamily={FONT_BENGALI} fontWeight={700} fontSize={23}>
            {label}
          </text>
        </g>
      )}
    </g>
  );
};

// ── রিং-পালস (সংকেত বা সাড়া বিন্দুতে স্পন্দন) ──
export const RingPulse: React.FC<{
  x: number;
  y: number;
  color: string;
  r?: number;
}> = ({ x, y, color, r = 28 }) => {
  const f = useCurrentFrame();
  const { fps } = useVideoConfig();
  const cycle = ((f / fps) % 1.2) / 1.2;
  const sc = 1 + cycle * 1.25;
  const op = (1 - cycle) * 0.65;
  return (
    <circle
      cx={x}
      cy={y}
      r={r * sc}
      fill="none"
      stroke={color}
      strokeWidth={4}
      opacity={op}
    />
  );
};
