export interface Theme {
  bg: string;
  surface: string;
  surfaceHi: string;
  border: string;
  text: string;
  muted: string;
  accent: string;
  onAccent: string;
  data: string;
  flow: string;
  good: string;
  warn: string;
  bad: string;
  indicator: string;
}

// ডার্ক ইঞ্জিনিয়ারিং ব্লুপ্রিন্ট (ব্যবহারকারীর নির্বাচিত থিম)
export const THEME: Theme = {
  bg: "#0B0F17",
  surface: "#151D2A",
  surfaceHi: "#1E293B",
  border: "rgba(242, 244, 248, 0.11)",
  text: "#F2F4F8",
  muted: "#8B9BB4",
  accent: "#F59E0B",
  onAccent: "#0B0F17",
  data: "#38BDF8",
  flow: "#60A5FA",
  good: "#2E9A4A",
  warn: "#E89808",
  bad: "#E84838",
  indicator: "rgba(245, 158, 11, 0.45)"
};
