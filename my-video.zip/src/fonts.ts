import { staticFile } from "remotion";

export const FONT_BENGALI = "HindSiliguriLocal";
export const FONT_DISPLAY = "PlayfairDisplayLocal";

export const fontStyles = `
@font-face {
  font-family: '${FONT_BENGALI}';
  src: url('${staticFile("assets/HindSiliguri-Regular.ttf")}') format('truetype');
  font-weight: 400;
  font-style: normal;
}
@font-face {
  font-family: '${FONT_BENGALI}';
  src: url('${staticFile("assets/HindSiliguri-Medium.ttf")}') format('truetype');
  font-weight: 500;
  font-style: normal;
}
@font-face {
  font-family: '${FONT_BENGALI}';
  src: url('${staticFile("assets/HindSiliguri-SemiBold.ttf")}') format('truetype');
  font-weight: 600;
  font-style: normal;
}
@font-face {
  font-family: '${FONT_BENGALI}';
  src: url('${staticFile("assets/HindSiliguri-Bold.ttf")}') format('truetype');
  font-weight: 700;
  font-style: normal;
}
@font-face {
  font-family: '${FONT_DISPLAY}';
  src: url('${staticFile("assets/PlayfairDisplay-VariableFont_wght.ttf")}') format('truetype');
  font-weight: 400 800;
  font-style: normal;
}
`;
