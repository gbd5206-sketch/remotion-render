import React from "react";
import { useCurrentFrame, useVideoConfig, interpolate } from "remotion";
import { Theme } from "../theme";
import { Layout } from "../layout";
import {
  RafiPerson,
  CementSack,
  PulleyWheel,
  TwoStoryHouse,
  WaterTank,
  PopIn,
  Idle
} from "../art/Kit";
import {
  MetricChip,
  StampBanner,
  VerticalRuler,
  RingPulse
} from "../components/Annotations";
import { clamp01, countAt, toBn } from "../motion";
import { FONT_BENGALI } from "../fonts";

// ══════════════════════════════════════════════════════════════════════════
// দৃশ্য ৫ (৩:১৮.২ - ৩:৫৮.৫): ৪০ ফুটের লম্বা নাইলনের দড়ি ও ২০ ফুট ছাদে উত্তোলন
// ══════════════════════════════════════════════════════════════════════════
export const Scene5FortyFootRopeSuccess: React.FC<{ theme: Theme; layout: Layout }> = ({ theme }) => {
  const f = useCurrentFrame();
  const { fps } = useVideoConfig();
  const t = (f + 198.2 * fps) / fps; // গ্লোবাল টাইম (১৯৮.২s থেকে ২৩৮.৫s)

  const groundY = 1180;
  const floor1Y = 820;
  const roofY = 460;
  const fixedPulleyX = 560;
  const fixedPulleyY = roofY + 35;
  const movablePulleyX = 480;
  const anchorX = 435;
  const rafiX = 730;

  // ১৯৮.২s - ২০৬.৫s: পা দিয়ে সিঁড়ির রেলিংয়ে ঠেকিয়ে বস্তা আলতো করে নিচে নামানো
  // ২০৬.৫s - ২১৯.০s: পাশের ঘর থেকে ৪০ ফুটের নাইলন দড়ি এনে দুটো কপিকলে পরানো
  // ২১৯.০s - ২৩৫.৫s: ছন্দের সাথে ৪০ ফুট দড়ি টেনে বস্তা সোজা ২০ ফুট উঁচু দোতলার ছাদে তোলা
  let sackBottomY = floor1Y;
  if (t < 206.5) {
    sackBottomY = interpolate(t, [199.0, 205.5], [floor1Y, groundY], {
      extrapolateLeft: "clamp",
      extrapolateRight: "clamp"
    });
  } else if (t >= 206.5 && t < 219.5) {
    sackBottomY = groundY;
  } else {
    sackBottomY = interpolate(t, [219.5, 235.5], [groundY, roofY + 95], {
      extrapolateLeft: "clamp",
      extrapolateRight: "clamp"
    });
  }

  const movableY = sackBottomY - 175;
  const isNylonRope = t >= 210.0;
  const ropeColor = isNylonRope ? theme.data : theme.accent;
  const spinDeg = (groundY - sackBottomY) * 2.4;

  // কাউন্টার: ৪০ ফুট দড়ি টানা ও ২০ ফুট উচ্চতায় ওঠা
  const pulledFeet = countAt(t, 219.5, 16.0, 0, 40);
  const liftedFeet = countAt(t, 219.5, 16.0, 0, 20);
  const reachedRoof = t >= 235.2;

  return (
    <g>
      <TwoStoryHouse theme={theme} groundY={groundY} floor1Y={floor1Y} roofY={roofY} buildingX={90} buildingW={310} />
      <g transform={`translate(240 ${roofY - 22})`}>
        <WaterTank theme={theme} scale={0.95} />
      </g>

      <line x1={60} y1={groundY} x2={1020} y2={groundY} stroke={theme.text} strokeWidth={5} strokeLinecap="round" />

      {/* ৪০ ফুটের নাইলনের দড়ির কুণ্ডলী (২০৮s থেকে ২১৮s পর্যন্ত পাশে দেখা যায়) */}
      {isNylonRope && (
        <PopIn at={Math.round(11.8 * fps)} x={885} y={groundY - 45}>
          <ellipse cx={0} cy={0} rx={52} ry={28} fill={theme.surfaceHi} stroke={theme.data} strokeWidth={5} />
          <ellipse cx={0} cy={-12} rx={42} ry={20} fill={theme.surface} stroke={theme.data} strokeWidth={4} />
          <text x={0} y={42} textAnchor="middle" fill={theme.data} fontFamily={FONT_BENGALI} fontWeight={700} fontSize={22}>
            ৪০ ফুট নাইলন
          </text>
        </PopIn>
      )}

      {/* কপিকলের দড়ি (নাইলনের উজ্জ্বল সায়ান রঙ) */}
      <line x1={anchorX} y1={roofY + 2} x2={anchorX} y2={movableY} stroke={ropeColor} strokeWidth={7} />
      <line x1={movablePulleyX + 45} y1={movableY} x2={fixedPulleyX - 45} y2={fixedPulleyY} stroke={ropeColor} strokeWidth={7} />
      <line
        x1={fixedPulleyX + 48}
        y1={fixedPulleyY}
        x2={rafiX - 28}
        y2={groundY - 195}
        stroke={ropeColor}
        strokeWidth={7}
        strokeDasharray="16 8"
        strokeDashoffset={t >= 219.5 ? -f * 3.2 : 0}
      />

      {/* স্থির ও চলনশীল কপিকল */}
      <g transform={`translate(${fixedPulleyX} ${fixedPulleyY})`}>
        <PulleyWheel theme={theme} r={48} spinDeg={spinDeg} lit={isNylonRope} />
      </g>
      <g transform={`translate(${movablePulleyX} ${movableY})`}>
        <PulleyWheel theme={theme} r={44} spinDeg={-spinDeg} movable={true} lit={isNylonRope} />
      </g>

      {/* ৫০ কেজির বস্তা (নামানো হচ্ছে → এরপর সোজা ২০ ফুট ছাদে উঠছে) */}
      <g transform={`translate(${movablePulleyX} ${sackBottomY})`}>
        <CementSack theme={theme} scale={1.08} lit={reachedRoof} label="৫০ কেজি" />
      </g>

      {/* সিঁড়ির রেলিংয়ে আলতো করে ঠেকানোর পালস (২০০s - ২০৪s) */}
      {t >= 200.0 && t < 205.0 && (
        <RingPulse x={360} y={floor1Y + 120} color={theme.accent} r={32} />
      )}

      {/* রাফি */}
      <g transform={`translate(${rafiX} ${groundY})`}>
        <Idle amp={3} speed={3}>
          <RafiPerson
            pose={reachedRoof ? "happy" : "pull"}
            theme={theme}
            scale={1.36}
            sweat={t < 208.0}
          />
        </Idle>
      </g>

      {/* ২ হাত টানে ১ হাত ওঠা ও ৪০ ফুট / ২০ ফুট কাউন্টার চিপ */}
      {t >= 220.0 && (
        <>
          <VerticalRuler
            x={370}
            yTop={roofY}
            yBottom={groundY}
            at={Math.round(22.0 * fps)}
            label={`${toBn(liftedFeet)} ফুট উচ্চতা`}
            color={theme.good}
            theme={theme}
          />
          <MetricChip
            x={850}
            y={580}
            at={Math.round(22.0 * fps)}
            value={`${toBn(pulledFeet)} ফুট`}
            unit="দড়ি টানা হয়েছে"
            status="data"
            theme={theme}
            w={260}
          />
          <MetricChip
            x={850}
            y={740}
            at={Math.round(24.5 * fps)}
            value="২ : ১ অনুপাত"
            unit="২ হাত টানে ১ হাত ওঠে"
            status="accent"
            theme={theme}
            w={260}
          />
        </>
      )}

      {reachedRoof && (
        <StampBanner
          x={540}
          y={360}
          at={Math.round(37.0 * fps)}
          text="✓ ২০ ফুট উঁচু দোতলার ছাদে পৌঁছেছে!"
          status="good"
          theme={theme}
          w={560}
        />
      )}
    </g>
  );
};

// ══════════════════════════════════════════════════════════════════════════
// দৃশ্য ৬ (৩:৫৮.৫ - ৪:২০.৩): ছাদের কার্নিশে তৃপ্ত রাফি ও জীবনের লক্ষ্যের শিক্ষা
// ══════════════════════════════════════════════════════════════════════════
export const Scene6ConclusionAndLifeLesson: React.FC<{ theme: Theme; layout: Layout }> = ({ theme }) => {
  const f = useCurrentFrame();
  const { fps } = useVideoConfig();
  const t = (f + 238.5 * fps) / fps; // গ্লোবাল টাইম (২৩৮.৫s থেকে ২৬০.৩৩s)

  const roofSurfaceY = 740;
  const showLifePath = t >= 250.0;

  const recapItems = [
    {
      num: "১",
      title: "কপিকল হাওয়া থেকে শক্তি বাড়ায় না",
      desc: "মোট কাজের পরিমাণ সবসময় সমান থাকে",
      at: 242.5
    },
    {
      num: "২",
      title: "বেশি দূরত্ব জুড়ে কম বল প্রয়োগ",
      desc: "৪০ ফুট দড়ি টেনে ২৫ কেজি বলেই ৫০ কেজি জয়",
      at: 246.0
    },
    {
      num: "৩",
      title: "ধৈর্য ধরে লম্বা পথ পাড়ি দিলে চাপ কমে",
      desc: "বড় লক্ষ্য অর্জনে তাড়াহুড়ো না করে ধারাবাহিক চেষ্টা",
      at: 251.5
    }
  ];

  return (
    <g>
      {/* উপরের মঞ্চ: ছাদের কার্নিশে রাখা বস্তা ও তৃপ্ত রাফি + ডানে জীবনের লক্ষ্যের পথ */}
      <rect x={80} y={roofSurfaceY} width={920} height={26} rx={8} fill={theme.surfaceHi} stroke={theme.text} strokeWidth={4} />

      {/* ছাদের পানির ট্যাংক */}
      <g transform={`translate(190 ${roofSurfaceY})`}>
        <WaterTank theme={theme} scale={1.0} lit={true} />
      </g>

      {/* ছাদের কার্নিশে রাখা ৫০ কেজির বস্তা */}
      <g transform={`translate(390 ${roofSurfaceY})`}>
        <CementSack theme={theme} scale={1.08} lit={true} label="৫০ কেজি" />
      </g>

      {/* তৃপ্ত রাফি বস্তার পাশে দাঁড়িয়ে */}
      <g transform={`translate(545 ${roofSurfaceY})`}>
        <Idle amp={2.5} speed={2}>
          <RafiPerson pose="happy" theme={theme} scale={1.26} sweat={false} />
        </Idle>
      </g>

      {/* ডানে: খাড়া কঠিন পথ বনাম ধৈর্যের দীর্ঘ সহজ পথ (২৫০s থেকে) */}
      {showLifePath && (
        <PopIn at={Math.round(11.5 * fps)} x={800} y={roofSurfaceY}>
          {/* লক্ষ্য চূড়া */}
          <polygon points="-140,0 0,-230 140,0" fill={theme.surface} stroke={theme.text} strokeWidth={4} />
          {/* খাড়া পথ (বেশি চাপ - লাল) */}
          <path d="M -110 -10 L -15 -205" stroke={theme.bad} strokeWidth={5} strokeDasharray="10 8" fill="none" />
          {/* দীর্ঘ ঘোরানো পথ (কম চাপ, ধৈর্য - সবুজ/অ্যাকসেন্ট) */}
          <path
            d="M 120 -10 Q -80 -55 75 -115 Q -55 -160 0 -220"
            stroke={theme.good}
            strokeWidth={6}
            fill="none"
          />
          <circle cx={0} cy={-238} r={14} fill={theme.accent} />
          <text x={0} y={-262} textAnchor="middle" fill={theme.accent} fontFamily={FONT_BENGALI} fontWeight={700} fontSize={24}>
            বড় লক্ষ্য
          </text>
        </PopIn>
      )}

      {/* নিচে ৩টি রিক্যাপ কার্ড (একটা একটা করে হাইলাইট হয়) */}
      {recapItems.map((item, idx) => {
        const active = t >= item.at;
        const cardY = 835 + idx * 145;
        const borderCol = active ? theme.accent : theme.border;
        return (
          <g key={idx} transform={`translate(540 ${cardY})`} opacity={active ? 1 : 0.45}>
            <rect x={-440} y={-54} width={880} height={116} rx={22} fill={theme.surface} stroke={borderCol} strokeWidth={active ? 3.5 : 2} />
            <rect x={-416} y={-34} width={68} height={68} rx={16} fill={active ? theme.accent : theme.surfaceHi} />
            <text
              x={-382}
              y={12}
              textAnchor="middle"
              fill={active ? theme.onAccent : theme.muted}
              fontFamily={FONT_BENGALI}
              fontWeight={700}
              fontSize={34}
            >
              {item.num}
            </text>
            <text x={-322} y={-6} fill={theme.text} fontFamily={FONT_BENGALI} fontWeight={700} fontSize={31}>
              {item.title}
            </text>
            <text x={-322} y={34} fill={theme.muted} fontFamily={FONT_BENGALI} fontWeight={600} fontSize={23}>
              {item.desc}
            </text>
          </g>
        );
      })}
    </g>
  );
};
